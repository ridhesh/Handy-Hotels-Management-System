# health-care
Download the files,
must have mysql or xampp in computer,
open backend folder on netbeans and run,
open frontend file on vscode and run.
main page of the site
![p1](https://user-images.githubusercontent.com/62055525/160253746-ccee00fa-23ab-4ae7-9e1a-338a774c8142.PNG)
update page
![p2](https://user-images.githubusercontent.com/62055525/160253760-41b4226e-cb1a-4473-a27b-eb6a76b3eff7.PNG)
show patient details
![p3](https://user-images.githubusercontent.com/62055525/160253774-9d64751d-1933-46ba-b33a-f017b8bf7ba3.PNG)
patient registration form
![p4](https://user-images.githubusercontent.com/62055525/160253788-6d46c886-b109-4e2f-9abd-dc61df5b46a1.PNG)
