package healthcaremanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeathcareManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
