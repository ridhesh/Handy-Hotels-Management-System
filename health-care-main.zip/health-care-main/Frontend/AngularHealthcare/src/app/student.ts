export class Student {
  id: number;
  patientName: string;
  gender: string;
  dob: string;
  phoneNumber: string;
  email: string;
  address: string;
}
